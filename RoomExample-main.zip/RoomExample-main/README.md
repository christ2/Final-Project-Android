![logo](https://i.imgur.com/Dv73hCk.png)
# RoomExample
Insert, Read, Update and Delete data from Room Database using Kotlin

https://johncodeos.com/how-to-use-room-in-android-using-kotlin