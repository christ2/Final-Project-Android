package com.example.roomexample

import java.util.*

data class Note(
    val dateAdded: Date,
    var noteText: String
)